import StyleSheet from 'react-native'
import Colors from '../../Contants/colors';
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:Colors.DEFAULT_WHITE,
    },
    vimg:{
        flex: 3,
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor:Colors.LIGHT_YELLOW,
    },
});
export default styles;