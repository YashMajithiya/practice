import React from 'react';
import {useEffect} from 'react';
import {
  StatusBar,
  View,
  Text,
  ImageBackground,
} from 'react-native';
import Buttons from '../../Components/Buttons';
import colors from '../../Contants/colors';
import styles from './OnBoardingstyle';

const OnBoarding = ({navigation}) => {
  return (
    <View
      style={styles.container}>
      {/* Adding status bar for the On Boarding Sceen */}
      <StatusBar
        barStyle="dark-content"
        hidden={false}
        backgroundColor={colors.DEFAULT_WHITE}
      />
      {/* Shows the Image on On Boarding Screen */}
      <View
        style={styles.vimg}>
        <ImageBackground
          source={require('../../../assets/expense.png')}
          style={{
            flex: 1,
            width: 430,
            height: 430,
            marginTop: 30,
            backgroundColor:colors.DEFAULT_WHITE,
          }}
        />
      </View>
      <View
        style={{
          flex: 2,
          backgroundColor:colors.DEFAULT_WHITE,
        }}>
        {/* Another Class for text and tagline of product */}
        <View
          style={{
            flex: 1,
            flexDirection: 'column',
            alignItems: 'center',
            backgroundColor: '#FFF',
            justifyContent: 'flex-start',
          }}>
          {/* Product Name */}
          <Text
            style={{
              fontFamily: 'Roboto',
              fontWeight: '700',
              color:colors.NIGHT_RIDER,
              fontSize: 30,
            }}>
            Expense Manager
          </Text>
          {/* Product Tagline */}
          <Text
            style={{
              maxWidth: '50%',
              fontFamily: 'Roboto',
              paddingTop: 10,
              fontSize: 17,
              textAlign: 'center',
              color:colors.Matterhorn,
            }}>
            Make money work in your favor.
          </Text>
        </View>

        <View
          style={{
            flex: 1,
            flexDirection: 'column',
            justifyContent: 'flex-end',
            alignItems: 'center',
          }}>
          <Buttons
            btn_text="Get Started"
            on_press={() => navigation.navigate('Login')}
            style={{
            backfaceVisibility: 'hidden',
            justifyContent: 'center',
            borderRadius: 100,
            height: 55,
            elevation: 5,
            textAlign: 'center',
            width: '50%',
            backgroundColor:colors.BACKGROUND_COLOR,
            marginBottom: 30,}}
          />
        </View>
      </View>
    </View>
  );
};

export default OnBoarding;
