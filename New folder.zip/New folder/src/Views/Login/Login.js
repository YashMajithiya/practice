import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  SafeAreaView,
  StatusBar
} from 'react-native';
import { TextInput } from '@react-native-material/core';
import Buttons from '../../Components/Buttons';
import colors from '../../Contants/colors';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import styles from './LoginStyles';

const Login = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <StatusBar
        barStyle="light-content"
        hidden={false}
        backgroundColor={colors.BACKGROUND_COLOR}
      />
      <SafeAreaView style={styles.headerWrapper}>
        <View style={styles.header}>
          <View>
            <Text style={styles.headerText}>Send Code</Text>
          </View>
          <View style={{ width: 20 }} />
        </View>
        <View style={styles.img}>
          <Image
            source={require('../../../assets/Payment.png')}
            style={{ width: 350, height: 350, paddingBottom: 30 }}
          />
        </View>
      </SafeAreaView>
      <KeyboardAwareScrollView>
        <View >
          <TextInput variant="outlined" label="Enter Phone Number" placeholder='+91'
            style={{
              width: 380, paddingTop: 30, alignSelf: "center", color: colors.DEFAULT_BLACK, fontFamily: 'Roboto',
            }} />

          <View
            style={{
              flex: 1,
              justifyContent: 'flex-end',
              alignItems: 'center',
              paddingTop: 40
            }}>
            <Buttons
              btn_text="Submit"
              on_press={() => navigation.navigate('VerifyOtp')}
              style={{
                backfaceVisibility: 'hidden',
                justifyContent: 'center',
                borderRadius: 100,
                height: 55,
                elevation: 5,
                textAlign: 'center',
                width: '50%',
                backgroundColor: colors.BACKGROUND_COLOR,
                marginBottom: 2
              }}
            />
          </View>
        </View>
      </KeyboardAwareScrollView>

    </View>
  );
};
export default Login;
