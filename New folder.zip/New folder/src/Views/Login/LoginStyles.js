import StyleSheet from 'react-native'
import Colors from '../../Contants/colors';
const styles = StyleSheet.create({
    container: {
        backgroundColor: Colors.DEFAULT_WHITE,
        height: "100%"
    },
    headerWrapper: {
        backgroundColor: Colors.BACKGROUND_COLOR,
        borderBottomLeftRadius: 25,
        borderBottomRightRadius: 25,
    },
    header: {
        padding: 20,
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    iconWhite: {
        color: Colors.DEFAULT_WHITE,
    },
    headerText: {
        fontWeight: 'bold',
        color: Colors.DEFAULT_WHITE,
        fontSize: 20,
    },
    img: {
        paddingBottom: 20,
        alignItems: 'center',
    },
});
export default styles;