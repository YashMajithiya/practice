import React from 'react';
import {useEffect} from 'react';
import {StatusBar, Image, View, Text} from 'react-native';
import colors from '../../Contants/colors';
import styles from './SplashScreenStyles';

const Splash = ({navigation}) => {
  setTimeout(() => {
    navigation.replace('OnBoarding');
  }, 2000);
  return (
    <View
      // Adding static style for the splash screen
      style={styles.container}>
      {/* Adding status bar for the Splash Sceen */}
      <StatusBar
        barStyle="dark-content"
        hidden={false}
        backgroundColor={colors.DEFAULT_WHITE}
      />
      {/* This is the main Logo Image */}
      <Image
        source={require('../../../assets/check.png')}
        style={styles.img}
      />
      {/* Company Tag or Product Name */}
      <Text
        style={styles.text}>
        Expense Manager
      </Text>
    </View>
  );
};

// Exporting the main class Splash
export default Splash;
