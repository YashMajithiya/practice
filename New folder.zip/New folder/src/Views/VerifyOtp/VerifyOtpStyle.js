import Display from '../../Contants/Display';
import StyleSheet from 'react-native'

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: Colors.DEFAULT_WHITE,
    },
    headerContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 10,
      paddingHorizontal: 20,
    },
    headerTitle: {
      fontSize: 20,
      fontFamily: "",
      lineHeight: 20 * 1.4,
      width: Display.setWidth(80),
      textAlign: 'center',
    },
    title: {
      fontSize: 20,
      fontFamily: "Roboto",
      lineHeight: 20 * 1.4,
      marginTop: 30,
      includeFontPadding:false,
      fontWeight:'700',
      color:Colors.DEFAULT_BLACK,
      marginBottom: 10,
      marginHorizontal: 20,
    },
    content: {
      fontSize: 20,
      fontFamily: "Roboto",
      marginTop: 10,
      marginBottom: 20,
      marginHorizontal: 20,
      fontWeight:'600',
      color:Colors.DEFAULT_BLACK,
    },
    phoneNumberText: {
      fontSize: 18,
      fontFamily: "Roboto",
  
      lineHeight: 18 * 1.4,
      color: Colors.DEFAULT_YELLOW,
    },
    otpContainer: {
      marginHorizontal: 6,
      marginBottom: 30,
      justifyContent: 'space-evenly',
      alignItems: 'center',
      flexDirection: 'row',
    },
    otpBox: {
      borderRadius: 5,
      borderColor: Colors.BACKGROUND_COLOR,
      borderWidth: 1.5,
    },
    otpText: {
      fontSize: 25,
      color: Colors.DEFAULT_BLACK,
      padding: 0,
      textAlign: 'center',
      paddingHorizontal: 18,
      paddingVertical: 10,
    },
    signinButton: {
      backgroundColor: Colors.DEFAULT_GREEN,
      borderRadius: 8,
      marginHorizontal: 20,
      height: Display.setHeight(6),
      justifyContent: 'center',
      alignItems: 'center',
      marginTop: 20,
    },
    signinButtonText: {
      fontSize: 18,
      lineHeight: 18 * 1.4,
      color: Colors.DEFAULT_WHITE,
      fontFamily: "Roboto",
    },
    headerWrapper: {
      backgroundColor: '#5D5FEF',
      borderBottomLeftRadius: 25,
      borderBottomRightRadius: 25,
    },
    header: {
      padding: 20,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    headerText: {
      fontWeight: 'bold',
      color: '#FFFFFF',
      fontSize: 20,
    },
    img: {
      paddingBottom: 20,
      alignItems: 'center',
    },
  });

  export default styles
  