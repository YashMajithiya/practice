import React, {useRef, useState} from 'react';
import {
  View,
  Text,
  StatusBar,
  TextInput,
  Image,
  SafeAreaView
} from 'react-native';
import Colors from '../../Contants/colors';
import Buttons from '../../Components/Buttons';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import styles from './VerifyOtpStyle';

const VerifyOtp = ({
  navigation
}) => {
  const firstInput = useRef();
  const secondInput = useRef();
  const thirdInput = useRef();
  const fourthInput = useRef();
  const fifthInput = useRef();
  const sixthInput = useRef();
  const [otp, setOtp] = useState({1: '', 2: '', 3: '', 4: '',5: '',6: ''});

  return (
    <View style={styles.container}>
       <StatusBar
        barStyle="dark-content"
        hidden={false}
        backgroundColor={Colors.BACKGROUND_COLOR}
      />
        <SafeAreaView style={styles.headerWrapper}>
        <View style={styles.header}>

          <View>
            <Text style={styles.headerText}>OTP Verification</Text>
          </View>
          <View style={{ width: 20 }} />
        </View>
        <View style={styles.img}>
          <Image
            source={require('../../../assets/Verified.png')}
            style={{ width: 350, height: 350, paddingBottom: 30 }}
          />

        </View>
      </SafeAreaView>
      <KeyboardAwareScrollView>
      <Text style={styles.title}>OTP Verification</Text>
      <Text style={styles.content}>
        Enter the OTP number just sent you at{' '}
      </Text>
   
      <View style={styles.otpContainer}>
        <View style={styles.otpBox}>
          <TextInput
            style={styles.otpText}
            keyboardType="number-pad"
            maxLength={1}
            ref={firstInput}
            onChangeText={text => {
              setOtp({...otp, 1: text});
              text && secondInput.current.focus();
            }}
          />
        </View>
        <View style={styles.otpBox}>
          <TextInput
            style={styles.otpText}
            keyboardType="number-pad"
            maxLength={1}
            ref={secondInput}
            onChangeText={text => {
              setOtp({...otp, 2: text});
              text ? thirdInput.current.focus() : firstInput.current.focus();
            }}
          />
        </View>
        <View style={styles.otpBox}>
          <TextInput
            style={styles.otpText}
            keyboardType="number-pad"
            maxLength={1}
            ref={thirdInput}
            onChangeText={text => {
              setOtp({...otp, 3: text});
              text ? fourthInput.current.focus() : secondInput.current.focus();
            }}
          />
        </View>
        <View style={styles.otpBox}>
          <TextInput
            style={styles.otpText}
            keyboardType="number-pad"
            maxLength={1}
            ref={fourthInput}
            onChangeText={text => {
              setOtp({...otp, 4: text});
              !text && thirdInput.current.focus();
            }}
          />
        </View>
        <View style={styles.otpBox}>
          <TextInput
            style={styles.otpText}
            keyboardType="number-pad"
            maxLength={1}
            ref={fifthInput}
            onChangeText={text => {
              setOtp({...otp, 5: text});
              !text && fourthInput.current.focus();
            }}
          />
        </View>
        <View style={styles.otpBox}>
          <TextInput
            style={styles.otpText}
            keyboardType="number-pad"
            maxLength={1}
            ref={sixthInput}
            onChangeText={text => {
              setOtp({...otp, 6: text});
              !text && fifthInput.current.focus();
            }}
          />
        </View>
      </View>
      <View
          style={{
            flex: 1,
            flexDirection: 'column',
            justifyContent: 'flex-end',
            alignItems: 'center',
          }}>
      <Buttons
        btn_text="Verify"
        on_press={() => navigation.navigate('Login')}
        style={{backfaceVisibility: 'hidden',
        justifyContent: 'center',
        borderRadius: 100,
        height: 55,
        elevation: 5,
        textAlign: 'center',
        width: '50%',
        backgroundColor: '#5D5FEF',
        marginBottom:30
        }}
        >
      </Buttons>
      </View>
      </KeyboardAwareScrollView>
    </View>
  );
};
export default VerifyOtp;


