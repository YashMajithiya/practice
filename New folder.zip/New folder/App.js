import React from 'react';
import {Dimensions, StatusBar, Text, View} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import Splash from './src/Views/SplashScreen/splashscreen';
import VerifyOtp from './src/Views/VerifyOtp/VerifyOtp';
import OnBoarding from './src/Views/OnBoarding/OnBoarding';
import Login from './src/Views/Login/Login';

// Assign the default styles to the root container
const Stack = createStackNavigator();

const App = () => {
  // Main function to initiate the application
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{headerShown: false}}>
        <Stack.Screen name="Splash" component={Splash} />
        <Stack.Screen name="OnBoarding" component={OnBoarding} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="VerifyOtp" component={VerifyOtp} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

// exporting default App;
export default App;
